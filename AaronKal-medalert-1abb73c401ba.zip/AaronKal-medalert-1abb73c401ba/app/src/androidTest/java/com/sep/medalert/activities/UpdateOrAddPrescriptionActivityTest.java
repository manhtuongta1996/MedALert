package com.sep.medalert.activities;

import android.app.Instrumentation;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sep.medalert.R;
import com.sep.medalert.fragments.AllPrescriptionsFragment;
import com.sep.medalert.model.Drug;


import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.InstrumentationRegistry.getInstrumentation;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.intent.Intents.intended;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.*;


/**
 * Created by Nelly on 29/09/2017.
 */
@RunWith(AndroidJUnit4.class)
public class UpdateOrAddPrescriptionActivityTest {
    @Rule
    public ActivityTestRule<UpdateOrAddPrescriptionActivity> mActivityTestRule = new ActivityTestRule<UpdateOrAddPrescriptionActivity>(UpdateOrAddPrescriptionActivity.class);
    private UpdateOrAddPrescriptionActivity mActivity = null;
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference firebaseReference;
    private ArrayList<Drug> prescriptions;
    private String testName = "testName";

    Instrumentation.ActivityMonitor monitorAddPrescription = getInstrumentation().addMonitor(AllPrescriptionsFragment.class.getName(),null,false);


    @Before
    public void setUp() throws Exception {
        mActivity = mActivityTestRule.getActivity();

        firebaseAuth = FirebaseAuth.getInstance();
       // firebaseReference = FirebaseDatabase.getInstance().getReference();

    }

    @Test
    public void testLaunch() {
        View view = mActivity.findViewById(R.id.tvUnit);

        assertNotNull(view);
    }

    @Test
    public void testAddPrescription() {
        onView(withId(R.id.etName))
                .perform(typeText(testName), closeSoftKeyboard());
        onView(withId(R.id.etDescription))
                .perform(typeText("test description"), closeSoftKeyboard());
        //  onView(withId(R.id.etComments))
        //          .perform(typeText("test comment"), closeSoftKeyboard());
        onView(withId(R.id.etSupply))
                .perform(typeText("100"), closeSoftKeyboard());
        onView(withId(R.id.btnSave))
                .perform(click());

        FirebaseUser user = firebaseAuth.getCurrentUser();
        //    final String testName = firebaseReference.child(user.getUid()).child("prescription").child(Drug).toString();

        firebaseReference = FirebaseDatabase.getInstance().getReference().child(user.getUid());
        firebaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (prescriptions != null) {
                    prescriptions.clear();
                }

                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Drug drug = data.getValue(Drug.class);
                    Log.d("drug ->", "" + drug);
                  //  prescriptions.add(drug);
                }
                  /*  for (Drug drug: prescriptions){
                        assertEquals(drug.getName(), testName);
                    } */
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }



            // assertNotNull(testName);




    @Test
    public void testDeleteAlert() {

    }

    @After
    public void tearDown() throws Exception {
        mActivity = null;
    }

}