package com.sep.medalert.activities;

import android.app.Activity;
import android.app.Instrumentation;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.view.View;

import com.sep.medalert.R;

import org.junit.After;
import org.junit.Before;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.InstrumentationRegistry.getInstrumentation;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.intent.Intents.intended;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.*;

/**
 * Created by Nelly on 29/09/2017.
 */

// requirements
// 1 - input an alert with a time, dosage and one of the days selected.


@RunWith(AndroidJUnit4.class)
public class AddAlertTimeActivityTest {
    @Rule
    public ActivityTestRule<AddAlertTimeActivity> mActivityTestRule = new ActivityTestRule<AddAlertTimeActivity>(AddAlertTimeActivity.class);
    private AddAlertTimeActivity mActivity = null;

    Instrumentation.ActivityMonitor monitorAddActivity = getInstrumentation().addMonitor(UpdateOrAddPrescriptionActivity.class.getName(),null,false);


    @Before
    public void setUp() throws Exception {
        mActivity = mActivityTestRule.getActivity();
    }

    @Test
    public void testLaunch() {
        View view = mActivity.findViewById(R.id.btnSave);

        assertNotNull(view);
    }

    @Test
    public void testAddAlert() {
        assertNotNull(mActivity.findViewById(R.id.npMinute));
/*
        int testHour = 1;
        int testMinute = 1;
        String testPeriod = "AM";
        int testDosage = 1;
        //Input hour minute second
        onView(withId(R.id.npHour))
                .perform(click());
        onView(withId(R.id.npMinute))
                .perform(click());
        onView(withId(R.id.npPeriod))
                .perform(click());

        //input dosage
        onView(withId(R.id.npDosage))
                .perform(click());
        closeSoftKeyboard();
*/
        //select day
        onView(withId(R.id.cbMonday))
                .perform(click());

        //select save
        onView(withId(R.id.btnSave))
                .perform(click());


        Activity mainActivity = getInstrumentation().waitForMonitorWithTimeout(monitorAddActivity, 5000);
        assertNotNull(mainActivity);
        mainActivity.finish();
    }

    @After
    public void tearDown() throws Exception {

    }

}