package com.sep.medalert.activities;

import android.app.Activity;
import android.app.Instrumentation;
import android.support.test.InstrumentationRegistry;
import android.support.test.espresso.intent.Intents;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sep.medalert.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.InstrumentationRegistry.getInstrumentation;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.intent.Intents.intended;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.*;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isClickable;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

/**
 * Created by Nelly on 29/09/2017.
 */
@RunWith(AndroidJUnit4.class)
public class RegisterActivityTest {
    @Rule
    public ActivityTestRule<RegisterActivity> mActivityTestRule = new ActivityTestRule<RegisterActivity>(RegisterActivity.class);

    private Activity mActivity = null;
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference firebaseReference;

    Instrumentation.ActivityMonitor monitor = getInstrumentation().addMonitor(LoginActivity.class.getName(),null,false);
    Instrumentation.ActivityMonitor monitorRegistration = getInstrumentation().addMonitor(NavigationDrawerActivity.class.getName(),null,false);

    private String mEmail;
    private String mPassword;
    private double min = Math.ceil(1.0);
    private double max = Math.floor(100.0);
    private double random = Math.floor(Math.random() * (max - min)) + min;
    @Before
    public void setUp() throws Exception {
        mActivity = mActivityTestRule.getActivity();
    }

    @Before
    public void initValidStrings() {
        // Specify a valid string.
        mEmail = "unittest" + random + "@gmail.com";
        mPassword = "Password";

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseReference = firebaseDatabase.getReference();
    }

    @Test
    public void testLoginButtonExists() {
        onView(withId(R.id.btnLogin)).check(matches(isClickable()));
    }

    @Test
    public void testLaunchOfRegisterActivityOnButtonClick() {
        assertNotNull(mActivity.findViewById(R.id.btnLogin));

        onView(withId(R.id.btnLogin)).perform(click());

        Activity loginActivty = getInstrumentation().waitForMonitorWithTimeout(monitor, 5000);
        //my monitor has actually returned register activity
        assertNotNull(loginActivty);
        loginActivty.finish();
    }


    @Test
    public void testUserCanRegisterSuccessfully() {
        //Write text to all these fields

      //  FirebaseUser user = firebaseAuth.getCurrentUser();
      //  String testEmail = firebaseReference.child(user.getEmail()).toString();
      //  assertNotEquals(mEmail, testEmail);

        onView(withId(R.id.etEmail))
                .perform(typeText(mEmail), closeSoftKeyboard());
        onView(withId(R.id.etPassword))
                .perform(typeText(mPassword), closeSoftKeyboard());
        onView(withId(R.id.etPassword2))
                .perform(typeText(mPassword), closeSoftKeyboard());

        //Intents.init();
        //click on register to commence registration
        onView(withId(R.id.btnConfirm)).perform(click(), closeSoftKeyboard());
        //Intents.release();
        //intended(hasComponent(NavigationDrawerActivity.class.getName()));

        Activity mainActivity = getInstrumentation().waitForMonitorWithTimeout(monitorRegistration, 5000);
        assertNotNull(mainActivity);
        mainActivity.finish();
    }

    @After
    public void tearDown() throws Exception {
        mActivity = null;
    }

}