package com.sep.medalert.activities;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.support.test.espresso.action.ViewActions;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.view.View;
import android.test.ActivityInstrumentationTestCase2;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.sep.medalert.R;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.InstrumentationRegistry.getInstrumentation;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.intent.Intents.intended;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static android.support.test.espresso.matcher.ViewMatchers.isClickable;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;
import static org.junit.Assert.*;

/**
 * Created by Nelly on 29/09/2017.
 */

// needs to test logging in.



@RunWith(AndroidJUnit4.class)
public class LoginActivityTest {
    @Rule
    public ActivityTestRule<LoginActivity> mActivityTestRule = new ActivityTestRule<LoginActivity>(LoginActivity.class);

    private LoginActivity mActivity = null;
    private FirebaseAuth firebaseAuth;

    Instrumentation.ActivityMonitor monitor = getInstrumentation().addMonitor(RegisterActivity.class.getName(),null,false);
    Instrumentation.ActivityMonitor monitorLogIn = getInstrumentation().addMonitor(NavigationDrawerActivity.class.getName(),null,false);
    Instrumentation.ActivityMonitor monitorLogInAlreadyLoggedIn = getInstrumentation().addMonitor(LoginActivity.class.getName(),null,false);


    @Before
    public void setUp() throws Exception {
        mActivity = mActivityTestRule.getActivity();
    }


    @Test
    public void testLaunch() {
        View view = mActivity.findViewById(R.id.imageView);

        assertNotNull(view);
    }

    @Test
    public void testFindET() {
        View view = mActivity.findViewById(R.id.etEmail);

        assertNotNull(view);
    }

    @Test
    public void testLaunchOfRegisterActivityOnButtonClick() {
        assertNotNull(mActivity.findViewById(R.id.btnReg));

        onView(allOf(withId(R.id.btnReg), withText("Register"))).perform(click());

        Activity registerActivty = getInstrumentation().waitForMonitorWithTimeout(monitor, 5000);

        //my monitor has actually returned register activity
        assertNotNull(registerActivty);
        registerActivty.finish();
    }

    @Test
    public void checkLoginButtonExists() {
        //onView(withId(R.id.btnLogin).check(matches(isClickable())));
        assertNotNull(mActivity.findViewById(R.id.btnConfirm));
    }

    @Test
    public void testSignOutUser() {
        //cant test across multiple activities :/
        firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() != null) {
            firebaseAuth.signOut();
        }
    }

    @Test
    public void testLoginUser(){

        assertNotNull(mActivity.findViewById(R.id.etEmail));

        //Input dummy account details to login
        onView(withId(R.id.etEmail))
                .perform(typeText("test12@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etPassword))
                .perform(typeText("password"), closeSoftKeyboard());

        //click on register to commence registration
        onView(withId(R.id.btnConfirm)).perform(click());

        Activity mainActivity = getInstrumentation().waitForMonitorWithTimeout(monitorLogIn, 5000);
        assertNotNull(mainActivity);
        mainActivity.finish();
    }

    @After
    public void tearDown() throws Exception {
        mActivity = null;
    }

    @Test
    public void onCreate() throws Exception {

    }

    @Test
    public void onCreate1() throws Exception {

    }

}