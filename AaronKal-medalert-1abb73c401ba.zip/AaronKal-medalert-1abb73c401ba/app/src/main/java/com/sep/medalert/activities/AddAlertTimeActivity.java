package com.sep.medalert.activities;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.sep.medalert.R;
import com.sep.medalert.model.PrescriptionInfo;
import com.sep.medalert.util.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class AddAlertTimeActivity extends AppCompatActivity {

    private NumberPicker npHour, npMinute, npPeriod, npDosage;
    private CheckBox cbMonday, cbTuesday, cbWednesday, cbThursday, cbFriday, cbSaturday, cbSunday;
    private TextView tvUnit;
    private Button btnSave;

    private DatabaseHelper databaseHelper;

    private PrescriptionInfo alertTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_alert_time);

        //Initiate databaseHandler
        databaseHelper = new DatabaseHelper(this);
        databaseHelper.authoriseUser();

        setTitle("Add Alert Time");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // show back button



        //Initiation and population of the views
        initiateViews();
        initiateFields();

        btnSave.setOnClickListener((View v) -> {saveAlert();});
    }

    // clicking back button finishes activity
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            // clicking back button
            case android.R.id.home:
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_CANCELED, returnIntent); // no result is returned
                Toast.makeText(getApplicationContext(), "Draft Deleted", Toast.LENGTH_SHORT).show();
                finish();
                break;

        }
        return true;
    }

    private void initiateViews() {
        //Time Picker
        npHour      = (NumberPicker) findViewById(R.id.npHour);
        npMinute    = (NumberPicker) findViewById(R.id.npMinute);
        npPeriod    = (NumberPicker) findViewById(R.id.npPeriod);

        //Dosage Picker
        npDosage    = (NumberPicker) findViewById(R.id.npDosage);
        tvUnit      = (TextView) findViewById(R.id.tvUnit);

        //Days Checkbox list
        cbMonday    = (CheckBox) findViewById(R.id.cbMonday);
        cbTuesday   = (CheckBox) findViewById(R.id.cbTuesday);
        cbWednesday = (CheckBox) findViewById(R.id.cbWednesday);
        cbThursday  = (CheckBox) findViewById(R.id.cbThursday);
        cbFriday    = (CheckBox) findViewById(R.id.cbFriday);
        cbSaturday  = (CheckBox) findViewById(R.id.cbSaturday);
        cbSunday    = (CheckBox) findViewById(R.id.cbSunday);

        btnSave     = (Button) findViewById(R.id.btnSave);
    }

    public void initiateFields() {
        // sets all checkboxes to be selected by default
        cbMonday.setChecked(true);
        cbTuesday.setChecked(true);
        cbWednesday.setChecked(true);
        cbThursday.setChecked(true);
        cbFriday.setChecked(true);
        cbSaturday.setChecked(true);
        cbSunday.setChecked(true);

        //Set Hour Range
        npHour.setMaxValue(12);
        npHour.setMinValue(1);

        //Set minute Range
        npMinute.setMaxValue(59);
        npMinute.setMinValue(0);

        // formats hours and minutes to be shown as 2 digits
        npHour.setFormatter(i -> String.format("%02d", i));
        npMinute.setFormatter(i -> String.format("%02d", i));

        npPeriod.setMaxValue(1);
        npPeriod.setMinValue(0);
        npPeriod.setDisplayedValues( new String[] {"AM", "PM"} ); // 0 and 1 are shown as AM and PM

        npDosage.setMinValue(1);

        // sets unit value from previous activity
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            tvUnit.setText("unit not set");
            npDosage.setMaxValue(100);
        } else {
            tvUnit.setText( extras.getString("unit") );
            npDosage.setMaxValue( extras.getInt("supply") );
        }
    }


    private void saveAlert() {
        // test data in fields is filled
        if (allFieldsFilled()) {

            // collate data into PrescriptionInfo object alertTime
            alertTime = new PrescriptionInfo(formatTime(), npDosage.getValue(), "Sunday", false, false,getDays());

            // send data back to parent activity
            Intent resultIntent = new Intent();
            resultIntent.putExtra("prescriptionInfo", alertTime);
            setResult(Activity.RESULT_OK, resultIntent); // result is returned
            finish();
        } else {
            Toast.makeText(getApplicationContext(), "Please select a day for this alert", Toast.LENGTH_SHORT).show();
        }
    }

    /*
    * returns the time from number pickers as a 24 hour string H:M
    */
    public String formatTime() {
        String s = "";
        int hrs;
        int min;

        // format time into 24 hour
        if (npPeriod.getValue() == 1) {
            hrs = npHour.getValue() + 12;
        } else {
            hrs = npHour.getValue();
            if (hrs == 12)
                hrs = 0;
        }
        min = npMinute.getValue();

        // return time as string
        s = String.valueOf(hrs) + ":" + String.valueOf(min);
        return s;
    }

    public List<Boolean> getDays() {
        List<Boolean> days = new ArrayList<>();

        days.add(cbMonday.isChecked());
        days.add(cbTuesday.isChecked());
        days.add(cbWednesday.isChecked());
        days.add(cbThursday.isChecked());
        days.add(cbFriday.isChecked());
        days.add(cbSaturday.isChecked());
        days.add(cbSunday.isChecked());

        return days;
    }

    /*
    * validate that all required fields are filled
    * - check to see if at least one day has been selected
    */
    public boolean allFieldsFilled() {
        // check that a least one day has been selected
        boolean validate = false;

        if (cbMonday.isChecked())
            validate = true;
        if (cbTuesday.isChecked())
            validate = true;
        if (cbWednesday.isChecked())
            validate = true;
        if (cbThursday.isChecked())
            validate = true;
        if (cbFriday.isChecked())
            validate = true;
        if (cbSaturday.isChecked())
            validate = true;
        if (cbSunday.isChecked())
            validate = true;

        return validate;
    }
}
