package com.sep.medalert.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.sep.medalert.R;
import com.sep.medalert.activities.DoctorDetailsActivity;
import com.sep.medalert.activities.PrescriptionDetailsActivity;
import com.sep.medalert.model.Doctor;

import java.util.ArrayList;

/**
 * Created by Nelly on 16/09/2017.
 */

public class DoctorListAdapter extends RecyclerView.Adapter<DoctorListAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Doctor> doctors = new ArrayList<Doctor>();

    public class ViewHolder extends RecyclerView.ViewHolder {
        protected TextView nameTv, specialityTv, mobileTv;
        protected ImageView iconIv;

        public ViewHolder(View view) {
            super(view);
            nameTv = (TextView) view.findViewById(R.id.tvDrName);
            specialityTv = (TextView) view.findViewById(R.id.tvDrSpeciality);
            mobileTv = (TextView) view.findViewById(R.id.tvDrMobile);
            iconIv = (ImageView) view.findViewById(R.id.ivDr);
        }
    }

    public DoctorListAdapter(Context context, ArrayList<Doctor> doctors) {
        this.context = context;
        this.doctors = doctors;
    }

    @Override
    public DoctorListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView =  LayoutInflater.from(parent.getContext())
                .inflate(R.layout.doctor_list, parent, false);

        ViewHolder vh = new ViewHolder(itemView);
        return vh;
    }

    @Override
    public void onBindViewHolder(DoctorListAdapter.ViewHolder holder, int position) {
        final Doctor doctor = doctors.get(position);

        //Setting the doctor details into the xml view
        holder.nameTv.setText(doctor.getName());
        holder.specialityTv.setText(doctor.getSpeciality());
        holder.mobileTv.setText(doctor.getMobile());

        //Setting icon imageview. Need to first find the resource icon because setImageResource only takes in int
        if(!(doctor.getIcon() == null)) {
            holder.iconIv.setImageResource(context.getResources().getIdentifier("drawable/ic_"+ doctor.getIcon(), null, context.getPackageName()));
        } else {
            holder.iconIv.setImageResource(R.drawable.ic_unselected);
        }

        //Prepared listener when item is clicked. Insert Activity when created Here
        holder.itemView.setOnClickListener((View v) -> directToDoctorDetails(v, doctor));
    }

    private void directToDoctorDetails(View v, Doctor doctor) {
        Intent detailsIntent = new Intent(v.getContext(), DoctorDetailsActivity.class);
        detailsIntent.putExtra("doctor", (Parcelable) doctor);
        v.getContext().startActivity(detailsIntent);
    }

    @Override
    public int getItemCount() {
        return doctors.size();
    }
}
