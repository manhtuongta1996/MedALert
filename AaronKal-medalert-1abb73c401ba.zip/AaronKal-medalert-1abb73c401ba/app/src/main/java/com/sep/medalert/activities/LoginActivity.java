package com.sep.medalert.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.sep.medalert.R;

public class LoginActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private ProgressBar progressBar;
    private ProgressDialog progressDialog;

    private EditText etEmail, etPassword;
    private Button btnConfirm, btnReg, btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        auth = FirebaseAuth.getInstance();
        //getSupportActionBar().hide();

        initiliseView();


        auth = FirebaseAuth.getInstance();

        //If user is already logged in then continue
        if (auth.getCurrentUser() != null) {
            finish();
            startActivity(new Intent(LoginActivity.this, NavigationDrawerActivity.class));
        }

        btnReg.setOnClickListener((View v) -> {
            finish();
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
        btnConfirm.setOnClickListener((View v) -> userLogin());
    }

    private void initiliseView() {
        etEmail = (EditText) findViewById(R.id.etEmail);
        etPassword = (EditText) findViewById(R.id.etPassword);
        btnConfirm = (Button) findViewById(R.id.btnConfirm);
        btnReg = (Button) findViewById(R.id.btnReg);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        progressDialog = new ProgressDialog(this);
    }

    private void userLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        //Check if the fields are empty
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
            return;
        }
        //If email & password are not empty
        progressDialog.setMessage("Logging Please Wait...");
        progressDialog.show();

        loginUser(email, password);
    }

    private void loginUser(String email, String password) {
        //login
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();

                        if(task.isSuccessful()) {
                            //start the profile activity
                            finish();
                            startActivity(new Intent(getApplicationContext(), NavigationDrawerActivity.class));
                        } else {
                            Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}