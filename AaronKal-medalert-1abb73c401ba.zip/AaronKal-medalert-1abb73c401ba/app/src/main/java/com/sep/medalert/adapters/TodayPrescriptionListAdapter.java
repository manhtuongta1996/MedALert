package com.sep.medalert.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.IgnoreExtraProperties;
import com.sep.medalert.R;
import com.sep.medalert.util.DatabaseHelper;
import com.sep.medalert.activities.PrescriptionDetailsActivity;
import com.sep.medalert.model.Drug;

import java.util.ArrayList;

/**
 * Created by Nelly on 25/08/2017.
 */

@IgnoreExtraProperties
public class TodayPrescriptionListAdapter extends RecyclerView.Adapter<TodayPrescriptionListAdapter.ViewHolder> {
    private final String TAG = "CustomAdapter";
    private Context context;
    private DatabaseHelper databaseHelper;
    private ArrayList<Drug> prescriptions = new ArrayList<Drug>();

    public class ViewHolder extends RecyclerView.ViewHolder {
        protected TextView nameTv, dosageTv, timeTv;
        private Button btnTakePill, btnSkipPill;
        protected ImageView presImgIv;
        protected CardView cardView;

        public ViewHolder(View view) {
            super(view);
            //cardView = (CardView)itemView.findViewById(R.id.card);
            nameTv = (TextView) view.findViewById(R.id.tvPresName);
            dosageTv = (TextView) view.findViewById(R.id.tvPresDesc);
            timeTv = (TextView) view.findViewById(R.id.tvPresTime);
            presImgIv = (ImageView) view.findViewById(R.id.ivPresPill);
            btnTakePill = (Button) view.findViewById(R.id.btnTakePill);
            btnSkipPill = (Button) view.findViewById(R.id.btnSkipPill);
        }
    }

    public TodayPrescriptionListAdapter(Context context, ArrayList<Drug> prescriptions) {
        this.context = context;
        this.prescriptions = prescriptions;
        databaseHelper = new DatabaseHelper((Activity) this.context);

    }

    @Override
    public TodayPrescriptionListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView =  LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.today_prescription_plan, parent, false);

        ViewHolder vh = new ViewHolder(itemView);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Drug drug = prescriptions.get(position);
        Log.i(TAG, drug.getDescription());

        int x = drug.getPrescriptionInfoAt(0).getDosage();
        String dosage = dosageString(drug.getUnit(),x);

        holder.nameTv.setText(drug.getName());
        //Setting icon imageview. Need to first find the resource icon because setImageResource only takes in int
        holder.presImgIv.setImageResource(context.getResources().getIdentifier("drawable/ic_"+ drug.getUnit().toLowerCase(), null, context.getPackageName()));
        holder.dosageTv.setText(dosage);

        ////////TODO////////////////////
        //Need to show every single instance of prescription for todays date
        //Need to sort prescription list based on time
        //This will be part of Release 2/3
        holder.timeTv.setText(drug.getPrescriptionInfo().get(0).timeFormatted());

        //Making each card clickable so can be taken into extra details page
        holder.itemView.setOnClickListener((View v) -> redirectToDetailsPage(v, drug));

        holder.btnTakePill.setOnClickListener((View v) -> {takePrescription(drug);});
        holder.btnSkipPill.setOnClickListener((View v) -> {skipPrescription(drug);});
    }

    private void redirectToDetailsPage(View v, Drug drug) {
        Intent detailsIntent = new Intent(v.getContext(), PrescriptionDetailsActivity.class);
        detailsIntent.putExtra("prescription", (Parcelable) drug);
        v.getContext().startActivity(detailsIntent);
    }

    private void takePrescription(Drug drug) {
        Runnable runnable = () -> { updateTakenPrescription(drug); };
        alertDialog(runnable, "Take Prescription", "Have you taken this prescription?", "yes", false);
    }

    private void updateTakenPrescription(Drug drug) {
        Drug newDrug = drug;
        int dosage = newDrug.getPrescriptionInfoAt(0).getDosage();
        int supply = newDrug.getSupply();
        if (supply >= dosage) {
            newDrug.setSupply(supply - dosage);
            newDrug.getPrescriptionInfoAt(0).setTaken(true);
            databaseHelper.editPrescription(drug, newDrug);
        } else {
            //figure out some type of error handling
        }
    }

    private void skipPrescription(Drug drug) {
        Runnable runnable = () -> { updateSkippedPrescription(drug); };
        alertDialog(runnable, "Skip Prescription", "Are you sure you want to skip taking this prescription? It will be deleted from todays plan!", "yes", false);
    }

    private void updateSkippedPrescription(Drug drug) {
        Drug newDrug = drug;
        newDrug.getPrescriptionInfoAt(0).setSkipped(true);
        databaseHelper.editPrescription(drug, newDrug);
    }

    /*
 *********Alert POP UP ***********
 */
    private void alertDialog(final Runnable runnable, String title, String message, String button, boolean addCustom) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(button,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) { new Handler().post(runnable);}
                });
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    @Override
    public int getItemCount() {
        return prescriptions.size();
    }

    //We can later change it to be s for suppositories instead of suppositorys
    public String dosageString(String unit, int dosageAmt) {
        String dosage = "Take " + dosageAmt + " " + unit;

        if(dosageAmt >1 )
            dosage += "(s)";

        return dosage;
    }
}
