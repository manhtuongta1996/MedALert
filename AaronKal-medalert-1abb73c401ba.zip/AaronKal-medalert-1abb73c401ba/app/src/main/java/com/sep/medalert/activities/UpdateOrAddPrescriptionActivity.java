package com.sep.medalert.activities;

import android.app.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.sep.medalert.R;
import com.sep.medalert.adapters.AlertListAdapter;
import com.sep.medalert.adapters.UnitPickerAdapter;
import com.sep.medalert.model.Drug;
import com.sep.medalert.model.PrescriptionInfo;
import com.sep.medalert.util.DatabaseHelper;

import java.util.ArrayList;
import java.util.Arrays;

public class UpdateOrAddPrescriptionActivity extends AppCompatActivity implements AlertListAdapter.ClickListener {

    private EditText etName, etDescription, etInstruction, etSupply;
    private Button btnSave;
    private TextView tvAlertHelp;
    private FloatingActionButton fabNewAlert;
    private RecyclerView rvAlerts;

    //Related to the dropdown (spinner) for prescription unit
    private Spinner spUnit;
    private String list[] = {"Ampoule", "Application", "Capsule", "Drop", "Gram", "Milligram", "Millilitre", "Puff", "Spray", "Suppository", "Tablet"};
    private ArrayList<String> units;

    //Data Object List
    private ArrayList<PrescriptionInfo> alertTimes;
    private Drug drug;

    private UnitPickerAdapter unitAdapter;
    private AlertListAdapter alertAdapter;

    private DatabaseHelper databaseHelper;

    String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_prescription);
        //Initiate databaseHandler
        databaseHelper = new DatabaseHelper(this);
        databaseHelper.authoriseUser();

        type = getIntent().getExtras().getString("Type");

        setTitle(type +" Prescription");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initiliseViews();

        setUpUnitAdapter();
        if(type.equals("Edit")) {
            drug = getIntent().getParcelableExtra("prescription");
            populateViews();
        }
        setUpAlertAdapter();

        setUpTextListenersandNotifiers();


        //Button Listeners
        btnSave.setOnClickListener((View v) -> save());
        fabNewAlert.setOnClickListener((View v) -> addAlert());

        // show or hide help text at start
        toggleAlertHelp();
    }

    private void populateViews() {
        // populate textview fields with drug data to be edited.
        etName.setText(drug.getName());
        etDescription.setText(drug.getDescription());
        etInstruction.setText(drug.getInstruction());
        etSupply.setText(String.valueOf(drug.getSupply()));

        // set unit spinner position
        spUnit.setSelection( unitAdapter.getPosition(drug.getUnit()) );

    }

    // clicking an alert in the recyclerview will show confirm dialog and delete alert
    @Override
    public void ItemClicked(View v, final int position) {

        if (alertTimes.size() > 0) {
            Runnable runnable = () -> { deleteAlert(position); };
            alertDialog(runnable, "Delete Alert?", "Are you sure you want to delete this alert?", "Delete", false);
        }
    }

    private void initiliseViews() {
        etName          = (EditText) findViewById(R.id.etName);
        etDescription   = (EditText) findViewById(R.id.etDescription);
        etInstruction   = (EditText) findViewById(R.id.etInstruction);
        etSupply        = (EditText) findViewById(R.id.etSupply);

        rvAlerts        = (RecyclerView) findViewById(R.id.rvAlerts);
        tvAlertHelp     = (TextView) findViewById(R.id.tvAlertHelp);

        btnSave         = (Button) findViewById(R.id.btnSave);
        fabNewAlert     = (FloatingActionButton) findViewById(R.id.fabNewAlert);
        spUnit = (Spinner)findViewById(R.id.spinner);
    }

    /*
    Methods relating to the set up of custom adapters
     */
    private void setUpUnitAdapter() {
        //Adding String array into List to prepare for adapter
        units = new ArrayList<String>(Arrays.asList(list));

        unitAdapter = new UnitPickerAdapter(this, R.layout.unit_picker_layout, R.id.txt, units);
        spUnit.setAdapter(unitAdapter);

        //Set default of dropdown to Tablet otherwise it defaults to ampoule
        spUnit.setSelection(10);
    }

    private void setUpAlertAdapter() {
        if(type.equals("Edit"))
            alertTimes = drug.getPrescriptionInfo();
        else
            alertTimes = new ArrayList<PrescriptionInfo>();

        alertAdapter = new AlertListAdapter(this, alertTimes, spUnit.getSelectedItem().toString());
        alertAdapter.setClickListener(this);

        rvAlerts.setAdapter(alertAdapter);
        rvAlerts.setLayoutManager(new LinearLayoutManager(this));
    }

    /*
    Methods relating to the setting up of listeners and notifiers for textviews and lists
     */

    private void setUpTextListenersandNotifiers() {
        addTextChangedListener(etName);
        addTextChangedListener(etDescription);
        addTextChangedListener(etSupply);

        //if unit is changed by user, updated alerts to show the new unit
        notifyAlertAdapter();
    }


    // set listeners on editText fields to remove errors once text is input
    private void addTextChangedListener(TextView tv) {
        tv.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                tv.setError(null);
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }

    //Notifies alert adapter if there has been a new unit that has been selected by user
    //Need this as alerts utilise the selected unit
    private void notifyAlertAdapter() {
        spUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                alertAdapter.setUnit(spUnit.getSelectedItem().toString());
                alertAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    /*
    Methods Relating to the saving of a Prescription
     */
    private void save() {
        // save drug info
        if (fieldsFilled()) {
            if (alertsCreated()) {
                saveUserPrescription();
                Toast.makeText(getApplicationContext(), "Prescription Saved", Toast.LENGTH_LONG).show();
                finish();
            } else
                Toast.makeText(getApplicationContext(), "Please add at least one alert before saving!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "All required fields must be filled", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveUserPrescription() {
        if(type.equals("Add"))
            databaseHelper.savePrescription(createDrug());
        else if(type.equals("Edit"))
            databaseHelper.editPrescription(drug, createDrug());
    }

    public Drug createDrug() {
        String name = etName.getText().toString();
        String desc = etDescription.getText().toString();
        String instr = etInstruction.getText().toString();
        String supply = etSupply.getText().toString();
        String units = spUnit.getSelectedItem().toString();

        //Creating drug to be saved
        Drug drug = new Drug(name, desc, instr, Integer.parseInt(supply), units);
        drug.addPrescriptionInfo(alertTimes);

        return drug;
    }

    /*
    Methods Relating to adding an alert to a prescription
     */
    private void addAlert() {
        if (!etSupply.getText().toString().equals("") && Integer.parseInt(etSupply.getText().toString()) > 0) {
            Intent resultIntent = new Intent(UpdateOrAddPrescriptionActivity.this, AddAlertTimeActivity.class);
            resultIntent.putExtra("unit", spUnit.getSelectedItem().toString());
            resultIntent.putExtra("supply", Integer.parseInt(etSupply.getText().toString()));
            startActivityForResult(resultIntent, 1);
        } else {
            Toast.makeText(getApplicationContext(), "Please input your supply count (must be greater than 0)", Toast.LENGTH_SHORT).show();
        }
    }

    public void deleteAlert(int index) {
        alertTimes.remove(index);
        Toast.makeText(getApplicationContext(), "Alert Deleted", Toast.LENGTH_SHORT).show();
        alertAdapter.notifyDataSetChanged();
        toggleAlertHelp();
    }

    public void toggleAlertHelp() {
        if (alertTimes.isEmpty())
            tvAlertHelp.setText("Press the + button to add alerts\nfor this prescription!\n");
        else
            tvAlertHelp.setText("");
    }

    /*
     Getting data back from AddAlertTimeActivity
      */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                PrescriptionInfo alertTime = data.getParcelableExtra("prescriptionInfo");

                if (alertClash(alertTime))
                   Toast.makeText(this, "New alert clashes with another alert!", Toast.LENGTH_LONG).show();

                alertTimes.add(alertTime);

                // update adapter to say data has changed
                alertAdapter.notifyDataSetChanged();
                toggleAlertHelp();

            } else if (resultCode == Activity.RESULT_CANCELED) {
                // do nothing as adding alert was canceled
            }
        }

    }

    /*
    * validate that all required fields are filled in correctly
    * */
    public boolean fieldsFilled() {
        boolean valid = true;
        valid = isFieldFilled(etName);
        valid = isFieldFilled(etDescription);
        if(isFieldFilled(etSupply)) {
            // if supply field is filled: check supply number is larger than all dosages in alertTimes?
            int supply = Integer.parseInt(etSupply.getText().toString());
            for (PrescriptionInfo alert : alertTimes) {
                if (alert.getDosage() > supply) {
                    valid = false;
                    etSupply.setError("Supply is lower than dosage!");
                    break;
                }
            }
        }
        return valid;
    }

    public boolean isFieldFilled(TextView tv) {
        if (tv.getText().toString().equals("")) {
            tv.setError("Required");
            return false;
        }
        return true;
    }

    /*
    * returns if the parameter alert clashes with any alert in the list: alertTimes
    * */
    public boolean alertClash(PrescriptionInfo alert) {
        // validate if there is an alert with the exact same day and time as the new alert
        for (PrescriptionInfo aT: alertTimes) {

            // check if they have the same time
            if (alert.getTime().equals(aT.getTime())) {

                // check if alert is on the same day
                for (int i = 0; i < 7; i++) {
                    if (alert.getDays().get(i) == aT.getDays().get(i))
                        return true;
                }
            }
        }

        return false; // no clash
    }

    /*
    * returns true if at least one alert has been created
    * */
    public boolean alertsCreated() {
        return (alertTimes.size() > 0);
    }

    private void alertDialog(final Runnable runnable, String title, String message, String button, boolean addCustom) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(button,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) { new Handler().post(runnable);}
                });
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    /*
 Clicking back button finishes activity
  */
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // clicking back button
            case android.R.id.home:
                Toast.makeText(getApplicationContext(), "Draft Deleted", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
        return true;
    }
}