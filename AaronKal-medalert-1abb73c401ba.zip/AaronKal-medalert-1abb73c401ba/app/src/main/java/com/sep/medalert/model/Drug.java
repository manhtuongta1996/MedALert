package com.sep.medalert.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import com.google.firebase.database.Exclude;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Nelly on 25/08/2017.
 */

public class Drug implements Parcelable, Comparable<Drug>{

    private String name, description, instruction, unit, key;
    private int supply, maxSupply;
    private ArrayList<PrescriptionInfo> prescriptionInfo = new ArrayList<PrescriptionInfo>();

    // constructor for creating using arguments
    // add prescriptionInfo list to prescription using method addPrescriptionInfo()
    public Drug(){super();}

    public Drug(String name, String description, String instruction, int supply, String unit) {
        super();
        this.name = name;
        this.instruction = instruction;
        this.description = description;
        this.supply = supply; // current supply
        this.maxSupply = supply; // max supply
        this.unit = unit;
        this.key = key;
    }

    public Drug(String name, String description, String instruction, int supply, String unit, String key, ArrayList<PrescriptionInfo> prescriptionInfo) {
        super();
        this.name = name;
        this.instruction = instruction;
        this.description = description;
        this.supply = supply; // current supply
        this.maxSupply = supply; // max supply
        this.unit = unit;
        this.key = key;
        this.prescriptionInfo = prescriptionInfo;
    }

    // constructor for creating drug from a parcel
    public Drug(Parcel parcel) {
        this.name = parcel.readString();
        this.description = parcel.readString();
        this.instruction = parcel.readString();
        this.supply = parcel.readInt();
        this.maxSupply = parcel.readInt();
        this.unit = parcel.readString();
        this.key = parcel.readString();
        parcel.readTypedList(this.prescriptionInfo, PrescriptionInfo.CREATOR);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.name);
        parcel.writeString(this.description);
        parcel.writeString(this.instruction);
        parcel.writeInt(this.supply);
        parcel.writeInt(this.maxSupply);
        parcel.writeString(this.unit);
        parcel.writeString(this.key);
        parcel.writeTypedList(prescriptionInfo);
    }

    public static final Creator<Drug> CREATOR = new Creator<Drug>() {
        @Override
        public Drug createFromParcel(Parcel parcel) {
            return new Drug(parcel);
        }

        @Override
        public Drug[] newArray(int i) {
            return new Drug[i];
        }
    };

    //Returns the percentage of remaining supply for prescription
    public float supplyRemaining() {
        return ((float)supply/maxSupply)*100;
    }

    @Exclude
    public String getSupplyRemainingColour() {
        return supplyRemaining() > 75 ? "#009933" : (supplyRemaining() <=25 ? "#cc2900" :  "#e68a00");
    }

    public String buildRemainingSupplyString() { return supply +"/"+maxSupply; }

    public String formatDesc() {
        String desc ="";
        return (getDescription().length() > 80) ? desc = getDescription().substring(0,80) +"...": getDescription();
    }

    // sets the max supply to the resupply value
    public void resupply(int value) {
        supply += value;
        if (supply > maxSupply)
            supply = maxSupply;
    }

    // resets the supply back to maxSupply
    public void maxResupply() {
        supply = maxSupply;
    }

    public void takeDosage(int dosage) {
        setSupply(getSupply() - dosage);
    }

    public void takeDrug(int dosage) {
        supply -= dosage;
    }

    public void addPrescriptionInfo(ArrayList<PrescriptionInfo> listOfPresInfo) {
        for(PrescriptionInfo presInfo: listOfPresInfo)
            prescriptionInfo.add(presInfo);
    }

    public PrescriptionInfo getPrescriptionInfoAt(int i) {
        return prescriptionInfo.get(i);
    }

    public int prescriptionInfoSize() {
        return prescriptionInfo.size();
    }

    // returns if today's date matches any alert in this drug
    public boolean checkTodayPre(){
        DateFormat df = new SimpleDateFormat("EEE");
        String date = df.format(Calendar.getInstance().getTime());
        for (PrescriptionInfo inf : getPrescriptionInfo()){
            if(inf.daysList().contains(date.toUpperCase())){
                return true;
            }
        }
        return false;
    }

    /*
    *Getters and Setters
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInstruction() {
        return instruction;
    }

    public void setInstruction(String instruction) {
        this.instruction = instruction;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUnit() { return unit; }

    public void setUnit(String unit) { this.unit = unit; }

    public String getKey() { return key; }

    public void setKey(String key) { this.key = key; }

    public int getSupply() { return supply; }

    public int getMaxSupply() { return maxSupply; }

    public void setMaxSupply(int maxSupply) {
        this.maxSupply = maxSupply;
    }

    public ArrayList<PrescriptionInfo> getPrescriptionInfo() { return this.prescriptionInfo; }

    public void setPrescriptionInfo(ArrayList<PrescriptionInfo> prescriptionInfo) { this.prescriptionInfo = prescriptionInfo; }

    public void setSupply(int supply) {
        this.supply = supply;
    }

    @Override
    public String toString() {
        return "Drug{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", instruction='" + instruction + '\'' +
                ", unit='" + unit + '\'' +
                ", supply=" + supply +
                ", maxSupply=" + maxSupply +
                ", key=" + key +
                ", prescriptionInfo=" + prescriptionInfo +
                '}';
    }

    @Override
    public int compareTo(@NonNull Drug anotherDrug) {
        return anotherDrug.getName().toLowerCase().compareTo(this.name.toLowerCase());
    }
}
