package com.sep.medalert.notifications;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.NotificationCompat;

import com.sep.medalert.R;
import com.sep.medalert.activities.NavigationDrawerActivity;
import com.sep.medalert.model.Drug;
import com.sep.medalert.model.PrescriptionInfo;

import java.util.List;

/**
 * Created by Jaspreet Panesar on 13/10/2017.
 */

public class AlarmNotification {

    /*
    * creates an alarm for each day in each alert in each drug
    * */
    public static void createAlarms(Context context, List<Drug> prescriptions) {
        int i=1;
        // go through each drug
        for (Drug drug : prescriptions) {

            // go through each alert/prescriptionInfo in drug
            for (int pinfo=0; pinfo<drug.getPrescriptionInfo().size(); pinfo++) {

                // go through each day for alert/prescriptionInfo
                for (int day = 0; day < 7; day++) {
                    PrescriptionInfo alert = drug.getPrescriptionInfoAt(pinfo);

                    // if alert is active on day, create an alarm for it
                    if (alert.getDays().get(day)) {
                        AlarmCreator.create(context, i, drug.getKey(), pinfo, Integer.parseInt(alert.getHour()), Integer.parseInt(alert.getMinute()), day);
                        i++;
                    }}}}
    }

    /*
    * cancels all alarms with id's 1 - 100
    * */
    public static void cancelAllAlarms(Context context) {
        for (int i=0; i<=100; i++)
            AlarmCreator.cancel(context, i);
    }

    /*
    * removes alarms and adds new ones provided by list: prescriptions
    * */
    public static void updateAlarms(Context context, List<Drug> prescriptions) {
        cancelAllAlarms(context);
        createAlarms(context, prescriptions);
    }


    /*
    * creates and shows a notificaiton which
    * */
    public static void showNotification(Context context, Intent intent, Drug drug) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        int id = intent.getIntExtra("notification-id", 0);
        String drugId = intent.getStringExtra("drug-id");
        int alertIndex = intent.getIntExtra("alert-index", 0);
        int hour = intent.getIntExtra("hour", 0);
        int minute = intent.getIntExtra("minute", 0);
        int day = intent.getIntExtra("day", 0);

        // if drug does not exist or prescriptionInfo, do not create notification
        if (drug == null)
            return;

        PrescriptionInfo pinfo = drug.getPrescriptionInfoAt(alertIndex);
        if (pinfo == null)
            return;

        // only show the notification if it is not taken or skipped yet
        if (!pinfo.isSkipped() && !pinfo.isTaken()) {
            Notification notification = buildNotification(context, id, drug.getName(), pinfo.getDosage(), drug.getUnit(),
                    drugId, alertIndex, hour, minute, day);
            notificationManager.notify(id, notification);
        }

        // recreate alarm
        AlarmCreator.create(context, id, drugId, alertIndex, hour, minute, day);
    }


    /*
    * builds a notification object from the provided parameters
    * */
    public static Notification buildNotification(Context context, int id, String name, int dosage, String unit, String drug_id, int alertIndex, int hour, int minute, int day) {

        // snooze and dismiss intent
        Intent snoozeI = new Intent(context, SnoozeAlarmReciever.class);
        snoozeI.putExtra("notification-id", id);
        snoozeI.putExtra("drug-id", drug_id);
        snoozeI.putExtra("alert-index", alertIndex);
        snoozeI.putExtra("hour", hour);
        snoozeI.putExtra("minute", minute);
        snoozeI.putExtra("day", day);

        Intent dismissI = new Intent(context, DismissAlarmReciever.class);
        dismissI.putExtra("notification-id", id);
        dismissI.putExtra("drug-id", drug_id);
        dismissI.putExtra("alert-index", alertIndex);
        dismissI.putExtra("hour", hour);
        dismissI.putExtra("minute", minute);
        dismissI.putExtra("day", day);

        Intent openI = new Intent(context, NavigationDrawerActivity.class);
        openI.putExtra("notification-id", id);
        openI.putExtra("drug-id", drug_id);
        openI.putExtra("alert-index", alertIndex);
        openI.putExtra("hour", hour);
        openI.putExtra("minute", minute);
        openI.putExtra("day", day);


        // pending intents for both
        PendingIntent snoozePI = PendingIntent.getBroadcast(context, id+10000, snoozeI, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent dismissPI = PendingIntent.getBroadcast(context, id+10001, dismissI, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent openPI = PendingIntent.getActivity(context, id+10002, openI, PendingIntent.FLAG_UPDATE_CURRENT);

        // notification actions
        NotificationCompat.Action snoozeA = new NotificationCompat.Action.Builder(R.drawable.ic_stat_snooze, "Snooze", snoozePI).build();
        NotificationCompat.Action dismissA = new NotificationCompat.Action.Builder(R.drawable.ic_stat_cancel, "Dismiss", dismissPI).build();


        NotificationCompat.Builder builder = (NotificationCompat.Builder) new NotificationCompat.Builder(context)
                .setTicker("MedAlert")
                .setContentTitle("MedAlert")
                .setContentText("It's time to take your " + name + " medication")
                .setSmallIcon(context.getResources().getIdentifier("ic_" + unit.toLowerCase(), "drawable", context.getPackageName()))
                .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE)
                .setContentIntent(openPI)
                .setAutoCancel(true)

                // setting big text style and buttons
                .setStyle(new NotificationCompat.BigTextStyle().bigText("It's time to take " + dosage + " " + unit + " of your " + name + " medication"))
                .addAction(dismissA)
                .addAction(snoozeA);

        return builder.build();
    }

}
