package com.sep.medalert.fragments;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.sep.medalert.R;
import com.sep.medalert.activities.UpdateOrAddPrescriptionActivity;
import com.sep.medalert.activities.NavigationDrawerActivity;
import com.sep.medalert.util.DatabaseHelper;

public class PrescriptionPlanFragment extends Fragment {

    /**,
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    //private SectionsPagerAdapter mSectionsPagerAdapter;
    private TabLayout tabLayout;
    private SectionsPagerAdapter mSectionsPagerAdapter;
    private NavigationDrawerActivity drawerMgr;


    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;
    private FloatingActionButton fab_addpres;
    private Animation FabOpen, FabRAnticlockwise;

    private DatabaseHelper databaseHelper;

    public PrescriptionPlanFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Initiate Database Handler
        databaseHelper = new DatabaseHelper(getActivity());
        databaseHelper.authoriseUser();

        getActivity().setTitle("Prescription Plan");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_prescription_plan, container, false);
        mSectionsPagerAdapter = new SectionsPagerAdapter(getChildFragmentManager());

        mViewPager = (ViewPager)view.findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout = (TabLayout)view.findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);

        //////////////////////Floating Action Button Initilising/////////////////////////////////////////////
        // Note that getActivity references NavigationDrawerActivity (Parent)
        initFab(view);
        fab_addpres.setOnClickListener((View v) -> setUpFabClicking());

        return view;
    }

    private void initFab(View view) {
        fab_addpres = (FloatingActionButton) view.findViewById(R.id.addpresBtn);
        FabOpen = AnimationUtils.loadAnimation(getActivity().getApplicationContext(), R.anim.addpres_open);
        FabRAnticlockwise = AnimationUtils.loadAnimation(getActivity().getApplicationContext(), R.anim.rotate_anticlockwise);
    }
    private void setUpFabClicking() {
        //Turning Animation on Add Prescription Button
        fab_addpres.startAnimation(FabOpen);
        fab_addpres.startAnimation(FabRAnticlockwise);

        // go to addPrescriptionActivity
        Intent addNewIntent = new Intent(getActivity(), UpdateOrAddPrescriptionActivity.class);
        addNewIntent.putExtra("Type", "Add");
        startActivity(addNewIntent);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mSectionsPagerAdapter = new SectionsPagerAdapter(getChildFragmentManager());
        mViewPager.setAdapter(mSectionsPagerAdapter);
    }


    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            switch(position) {
                case 0:
                    AllPrescriptionsFragment allPlan = new AllPrescriptionsFragment();
                    return allPlan;
                case 1:
                    TodayPrescriptionPlanFragment todayPlan = new TodayPrescriptionPlanFragment();
                    return todayPlan;
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "ALL PRESCRIPTIONS";
                case 1:
                    return "TODAY";
            }
            return null;
        }
    }
}