package com.sep.medalert.fragments;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sep.medalert.R;
import com.sep.medalert.adapters.AllPrescriptionListAdapter;
import com.sep.medalert.model.Drug;
import com.sep.medalert.notifications.AlarmNotification;
import com.sep.medalert.util.DatabaseHelper;

import java.util.ArrayList;
import java.util.Collections;


/**
 * Created by Nelly on 16/09/2017.
 */

public class AllPrescriptionsFragment extends Fragment {
    //Want to see if I can later on refactor and make PrescriptionListFragment into one that holds both today and all prescription List view
    private final String TAG = "PrescriptionPlan";
    private TextView tvHelpText, tvAlertsHelpText;

    private RecyclerView prescriptionsRv;
    private RecyclerView.Adapter prescriptionsAdapter;

    private ArrayList<Drug> prescriptions;

    private DatabaseHelper databaseHelper;

    public AllPrescriptionsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Initiate Database Handler
        databaseHelper = new DatabaseHelper(getActivity());
        databaseHelper.authoriseUser();

        prescriptions = new ArrayList<Drug>();
        getData();
    }

    public void getData() {
        DatabaseReference databaseReference = databaseHelper.getFirabaseReference();
        databaseReference.child(databaseHelper.getUserId()).child("prescription").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // clears the list before adding new items to it so it doesn't get duplicates
                prescriptions.clear();

                for(DataSnapshot data: dataSnapshot.getChildren())  {
                    Drug drug = data.getValue(Drug.class);
                    prescriptions.add(drug);
                }

                sortPrescriptionsAlphabetically();
                // update the recyclerview when the data set is returned
                prescriptionsAdapter.notifyDataSetChanged();

                // show help text is list is empty
                if (prescriptions.size() > 0)
                    tvHelpText.setVisibility(View.GONE);
                else
                    tvHelpText.setVisibility(View.VISIBLE);

                AlarmNotification.updateAlarms(getContext(), prescriptions);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void sortPrescriptionsAlphabetically() {
       Collections.sort(prescriptions, (p1, p2) -> p1.getName().toLowerCase().compareTo(p2.getName().toLowerCase()));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_prescription_list, container, false);

        //Adding custom adapter to listview to allow custom formatting of required fields in listview
        prescriptionsAdapter = new AllPrescriptionListAdapter(getActivity(),prescriptions);
        prescriptionsRv = (RecyclerView) view.findViewById(R.id.rvPrescription);

        tvHelpText = (TextView) view.findViewById(R.id.tvHelpText);
        tvAlertsHelpText = (TextView) view.findViewById(R.id.tvAlertsHelpText);
        tvAlertsHelpText.setVisibility(View.GONE); // hide alert help text on this page

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        prescriptionsRv.setHasFixedSize(true);

        // use a linear layout manager
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        prescriptionsRv.setLayoutManager(mLayoutManager);


        prescriptionsRv.setAdapter(prescriptionsAdapter);
        return view;
    }
}
