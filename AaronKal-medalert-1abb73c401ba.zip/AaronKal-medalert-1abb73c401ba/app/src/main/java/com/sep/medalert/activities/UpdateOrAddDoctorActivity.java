package com.sep.medalert.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.sep.medalert.R;
import com.sep.medalert.adapters.ImageListAdapter;
import com.sep.medalert.model.Doctor;
import com.sep.medalert.util.DatabaseHelper;


public class UpdateOrAddDoctorActivity extends AppCompatActivity {

    private EditText etName, etMobile, etPhone, etFax, etEmail, etClinicName, etClinicAddress, etSpeciality;
    private Button btnSave;

    private RecyclerView imgRv;
    private ImageListAdapter imgAdapter;

    private DatabaseHelper databaseHelper;

    private String type;
    private Doctor doctor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_doctor);
        //Initiate databaseHandler
        databaseHelper = new DatabaseHelper(this);
        databaseHelper.authoriseUser();

        type = getIntent().getExtras().getString("Type");

        setTitle(type + " Doctor");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initiliseViews();
        setImageListAdapter();

        //Only populate EditText if this is edit page
        if(type.equals("Edit")) {
            doctor = getIntent().getParcelableExtra("doctor");
            populateViews();
        }

        btnSave.setOnClickListener((View v) -> {save();});
    }

    private void populateViews() {
        etName.setText(doctor.getName());
        etMobile.setText(doctor.getMobile());
        etPhone.setText(doctor.getPhone());
        etFax.setText(String.valueOf(doctor.getFax()));
        etEmail.setText(doctor.getEmail());
        etClinicName.setText(doctor.getClinicName());
        etClinicAddress.setText(doctor.getClinicAddress());
        etSpeciality.setText(doctor.getSpeciality());
    }

    private void initiliseViews() {
        etName          = (EditText) findViewById(R.id.etName);
        etMobile        = (EditText) findViewById(R.id.etMobile);
        etPhone         = (EditText) findViewById(R.id.etPhone);
        etFax           = (EditText) findViewById(R.id.etFax);
        etEmail         = (EditText) findViewById(R.id.etEmail);
        etClinicName    = (EditText) findViewById(R.id.etClinicName);
        etClinicAddress = (EditText) findViewById(R.id.etClinicAddress);
        etSpeciality    = (EditText) findViewById(R.id.etSpeciality);

        btnSave         = (Button) findViewById(R.id.btnSave);
    }

    /*
    Custom adapter to display doctor icons in a horizontal view
     */
    private void setImageListAdapter() {
        imgAdapter = new ImageListAdapter(this, "doctor", 10);
        imgRv = (RecyclerView) findViewById(R.id.rvDoctorIconList);
        //Make sure it is horizontal list
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        imgRv.setLayoutManager(layoutManager);

        imgRv.setAdapter(imgAdapter);
    }

    /*
    Methods relating to saving a doctor into firebase
     */

    private void save() {
        if (fieldsFilled()) {
            if(type.equals("Edit")) {
                updateDoctor();
            } else {
                saveDoctor();
            }
            Toast.makeText(getApplicationContext(), "Doctor Saved", Toast.LENGTH_LONG).show();
            finish();
        } else {
            Toast.makeText(getApplicationContext(), "All required fields must be filled", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateDoctor() { databaseHelper.updateDoctor(doctor.getPushId(), createDoctor());}
    private void saveDoctor() {
        databaseHelper.saveDoctor(createDoctor());
    }


    private Doctor createDoctor() {
        String name = etName.getText().toString();
        String mobile = etMobile.getText().toString();
        String phone = etPhone.getText().toString();
        String fax = etFax.getText().toString();
        String email = etEmail.getText().toString();
        String clinicName = etClinicName.getText().toString();
        String clinicAddress = etClinicAddress.getText().toString();
        String speciality = etSpeciality.getText().toString();
        String image = imgAdapter.getSelectedImgView();
        //Creating drug to be saved
        return new Doctor(name, mobile, phone, fax, email, clinicName, clinicAddress, speciality, image);

    }

    /*
    Validation of fields
     */
    public boolean fieldsFilled() {
        boolean valid = true;

        valid = checkIfFieldValid(etName);
        valid = checkIfFieldValid(etPhone);
        valid = checkIfFieldValid(etClinicAddress);

        return valid;
    }

    public boolean checkIfFieldValid(TextView tv) {
        if (tv.getText().toString().equals("")) {
            tv.setError("Required");
            return false;
        }
        return true;
    }

    /*
     clicking back button finishes activity
      */
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            // clicking back button
            case android.R.id.home:
                Toast.makeText(getApplicationContext(), "Draft Deleted", Toast.LENGTH_SHORT).show();
                finish();
                break;

        }
        return true;
    }

}
