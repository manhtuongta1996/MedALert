package com.sep.medalert.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.sep.medalert.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nelly on 18/09/2017.
 */

public class UnitPickerAdapter extends ArrayAdapter<String> {
    int groupid;
    Activity context;
    ArrayList<String> list;
    LayoutInflater inflater;

    public UnitPickerAdapter(Activity context, int groupid, int id, ArrayList<String>
            list){
        super(context,id, (List<String>) list);
        this.list=list;
        inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.groupid=groupid;
        this.context = context;
    }

    public View getView(int position, View convertView, ViewGroup parent ){
        View itemView=inflater.inflate(groupid,parent,false);
        //Setting icon for spinner image. Need to first find the resource icon because setImageResource only takes in int
        ImageView imageView=(ImageView)itemView.findViewById(R.id.img);
        int id = context.getResources().getIdentifier("drawable/ic_"+ list.get(position).toLowerCase(), null, context.getPackageName());
        imageView.setImageResource(id);

        //Setting the text for spinner
        TextView textView=(TextView)itemView.findViewById(R.id.txt);
        textView.setText(list.get(position));
        return itemView;
    }

    public View getDropDownView(int position, View convertView, ViewGroup
            parent){
        return getView(position,convertView,parent);

    }

//    public int getCount() {
//        return list.size();
//    }
}
