package com.sep.medalert.model;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.RequiresApi;

import com.google.firebase.database.Exclude;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by Nelly on 25/08/2017.
 */

public class PrescriptionInfo implements Parcelable {

    private String time, day;
    private int dosage;
    private List<Boolean> days;
    private boolean isTaken, isSkipped;

    public PrescriptionInfo(){super();}

    public PrescriptionInfo(String time, int dosage, String day, boolean isTaken, boolean isSkipped, List<Boolean> days) {
        super();
        this.time = time;
        this.dosage = dosage;
        this.days = days;
        this.day = day;
        this.isTaken = isTaken;
        this.isSkipped = isSkipped;
    }

    // constructor for Parcelable class
    public PrescriptionInfo(Parcel parcel) {
        this.time = parcel.readString();
        this.dosage = parcel.readInt();
        this.day = parcel.readString();
        this.isTaken = parcel.readInt() == 1;
        this.isSkipped = parcel.readInt() == 1;
        this.days = new ArrayList<>(7);

        boolean[] daylist = parcel.createBooleanArray();
        for (int i=0; i<daylist.length; i++)
            this.days.add(daylist[i]);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.time);
        parcel.writeInt(this.dosage);
        parcel.writeString(this.day);
        parcel.writeInt(this.isTaken ? 1:0);
        parcel.writeInt(this.isSkipped ?1:0);

        boolean[] daylist = new boolean[7];
        for (int j=0; j<daylist.length; j++)
            daylist[j] = this.days.get(j);
        parcel.writeBooleanArray(daylist);
    }

    public static final Creator<PrescriptionInfo> CREATOR = new Creator<PrescriptionInfo>() {
        @Override
        public PrescriptionInfo createFromParcel(Parcel parcel) {
            return new PrescriptionInfo(parcel);
        }

        @Override
        public PrescriptionInfo[] newArray(int i) {
            return new PrescriptionInfo[i];
        }
    };

    // returns a string which displays which days this prescriptionInfo/alert is active
    public String daysList() {
        String[] daylist = {"MON ", "TUE ", "WED ", "THU ", "FRI ", "SAT ", "SUN "};
        String s = "";

        for (int i=0; i<daylist.length; i++)
            if (days.get(i))
                s += daylist[i];
            else
                s += "___ ";

        return s;
    }

    @Exclude
    public boolean isAvailableForToday() {
        return !isTaken() && !isSkipped();
    }

    //I think this date stuff should be in a util class not here
    public boolean isTodayDate(String dayOfWeek) {
        return day.equals(dayOfWeek);
    }

    // formats the time from 24 hour to 12 hours and returns it as a string
    public String timeFormatted() {
        String t = "";
        String[] split = this.time.split(":");
        int hrs = Integer.parseInt(split[0]);
        String period = "";

        // format time from 24 hour to 12 hour
        if (hrs >= 13) {
            hrs -= 12;
            period = "PM";
        } else if (hrs == 12) {
            period = "PM";
        } else if (hrs == 0) {
            hrs = 12;
            period = "AM";
        } else {
            period = "AM";
        }

        String hours, minutes;

        // adds a 0 in front of hour if its smaller than 10
        if (hrs < 10)
            hours = "0" + String.valueOf(hrs);
        else
            hours = String.valueOf(hrs);

        // adds a 0 in front of minute if its smaller than 10
        if (Integer.parseInt(split[1]) < 10)
            minutes = "0" + split[1];
        else
            minutes = split[1];

        // format time into one string
        t =  hours + ":" + minutes + " "  + period;
        return t;
    }

    public String getHour() {
        return time.split(":")[0];
    }

    public String getMinute() {
        return time.split(":")[1];
    }

    /*
    *Getters and Setters
     */

    public String getDay() { return day;}

    public void setDay(String day) {this.day = day;}

    public boolean isTaken() {return isTaken;}

    public void setTaken(boolean taken) {isTaken = taken;}

    public boolean isSkipped() {return isSkipped;}

    public void setSkipped(boolean skipped) {isSkipped = skipped;}

    public List<Boolean> getDays() {
        return days;
    }

    public void setDays(List<Boolean> days) {
        this.days = days;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getDosage() {
        return dosage;
    }

    public void setDosage(int dosage) {
        this.dosage = dosage;
    }

    @Override
    public String toString() {
        return "PrescriptionInfo{" +
                "time='" + time + '\'' +
                ", day='" + day + '\'' +
                ", dosage=" + dosage +
                ", days=" + days +
                ", isTaken=" + isTaken +
                ", isSkipped=" + isSkipped +
                '}';
    }
}
