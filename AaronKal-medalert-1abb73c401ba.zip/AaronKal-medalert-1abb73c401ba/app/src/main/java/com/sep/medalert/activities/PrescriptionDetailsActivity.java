package com.sep.medalert.activities;


import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sep.medalert.R;
import com.sep.medalert.adapters.AlertListAdapter;
import com.sep.medalert.model.Drug;
import com.sep.medalert.util.DatabaseHelper;

public class PrescriptionDetailsActivity extends AppCompatActivity {

    private TextView tvDescription, tvInstruction, tvSupply;
    private Button btnResupply, btnEdit, btnDelete;
    private ProgressBar pbSupply;
    private RecyclerView rvAlerts;
    private AlertListAdapter adapter;
    private CardView cvInstructions;

    private Drug drug;

    private FirebaseAuth firebaseAuth;
    private FirebaseUser user;
    private DatabaseReference firebaseReference;

    private NumberPicker npSupply;
    private Spinner spinnerOptions;

    private DatabaseHelper databaseHelper;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_persecription_details, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Initiate databaseHandler
        databaseHelper = new DatabaseHelper(this);
        databaseHelper.authoriseUser();

        //Retrieve drug object from the prescription plan
        drug = getIntent().getParcelableExtra("prescription");


        //GOING TO EXTRACT TO DATABASE HANDLER
        firebaseAuth = firebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        firebaseReference = FirebaseDatabase.getInstance().getReference();


        initiliseViews();
        populateViews();

        setUpAdapter();

        //Top Buttons
        btnResupply.setOnClickListener((View v) -> {resupply();});
        btnEdit.setOnClickListener((View v) -> {editPrescription();});
        btnDelete.setOnClickListener((View v) -> {deletePrescription();});
    }

    /*
    Methods Related to initilising and setting up the view
     */
    private void initiliseViews() {
        tvDescription   = (TextView) findViewById(R.id.tvDescription);
        tvInstruction   = (TextView) findViewById(R.id.tvInstruction);
        tvSupply        = (TextView) findViewById(R.id.tvSupply);
        pbSupply        = (ProgressBar) findViewById(R.id.pbSupply);
        rvAlerts        = (RecyclerView) findViewById(R.id.rvAlerts);
        cvInstructions  = (CardView) findViewById(R.id.cvInstructions);
        btnResupply     = (Button) findViewById(R.id.btnResupply);
        btnEdit     = (Button) findViewById(R.id.btnEdit);
        btnDelete     = (Button) findViewById(R.id.btnDelete);
    }

    private void populateViews() {
        setTitle(drug.getName());

        tvDescription.setText(drug.getDescription());
        tvSupply.setText( drug.buildRemainingSupplyString() + " " + drug.getUnit() + "(s) remaining" );
        tvInstruction.setText(drug.getInstruction());

        // if there are no instructions set for prescription, don't show the instruction card view
        if (drug.getInstruction().equals(""))
            cvInstructions.setVisibility(View.GONE);
        else
            cvInstructions.setVisibility(View.VISIBLE);

        setUpProgressBar();
    }

    private void setUpProgressBar() {
        pbSupply.setProgress((int) drug.supplyRemaining());
        // changes colour of the supply bar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            pbSupply.setProgressTintList(ColorStateList.valueOf(Color.parseColor(drug.getSupplyRemainingColour())));
        }
    }

    //Alert List adapter
    private void setUpAdapter() {
        adapter = new AlertListAdapter(this, drug.getPrescriptionInfo(), drug.getUnit());
        rvAlerts.setLayoutManager(new LinearLayoutManager(this));
        rvAlerts.setAdapter(adapter);
    }


    // clicking back button finishes activity
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // clicking back button
            case android.R.id.home:
                finish();
                break;

            case R.id.resupply_prescription:
                resupply();
                break;

            // clicking edit button
            case R.id.edit_prescription:
                editPrescription();
                break;

            case R.id.delete_prescription:
                deletePrescription();
                break;
        }
        return true;
    }

    /*
     ********** Resupply Methods ************
      */
    private void resupply() {
        Runnable runnable = () -> { resupplying(); };
        alertDialog(runnable, "Resupplying", "Select an amount to resupply " + drug.getName(), "Resupply", true);
    }

    private void resupplying() {
        // resupply drug to max if "full" option is selected
        if (spinnerOptions.getSelectedItem().toString().equals("Full"))
            drug.maxResupply();
        else
            drug.resupply(npSupply.getValue());

        // edit prescription in the database by deleting the older version (using key)
        // and creating a new one with the same values
        databaseHelper.editPrescription(drug, drug);

        Toast.makeText(getApplicationContext(), drug.getName() + " resupplied", Toast.LENGTH_SHORT).show();
        finish(); // close the prescription description page
    }

    /**
     * *******Edit Prescription Methods *********
      */

    private void editPrescription() {
        // Toast.makeText(getApplicationContext(), "Edit Prescription" , Toast.LENGTH_SHORT).show();
        Intent editIntent = new Intent(PrescriptionDetailsActivity.this, UpdateOrAddPrescriptionActivity.class);
        editIntent.putExtra("prescription", drug);
        editIntent.putExtra("Type", "Edit");
        startActivity(editIntent);
        finish(); //close
    }

    /**
     ********* Delete Prescription Methods ******
     */
    private void deletePrescription() {
        Runnable runnable = () -> { confirmDeletePrescription(); };
        alertDialog(runnable, "Delete Prescription", "Are you sure you want to delete this prescription?", "yes", false);
    }

    private void confirmDeletePrescription() {
        Toast.makeText(getApplicationContext(), "Prescription Deleted", Toast.LENGTH_SHORT).show();
        deletePrescriptionFromDb();
        finish();
    }
    private void deletePrescriptionFromDb() {
        firebaseReference.child(user.getUid()).child("prescription").child(drug.getKey()).removeValue();
    }

    /*
     *********Alert POP UP ***********
     */
    private void alertDialog(final Runnable runnable, String title, String message, String button, boolean addCustom) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        //Done for the Resupply custom view
        if(addCustom) customResupplyAlertDialog(builder);
        builder.setPositiveButton(button,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) { new Handler().post(runnable);}
                });
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void customResupplyAlertDialog(AlertDialog.Builder builder) {
        LayoutInflater inflator = LayoutInflater.from(builder.getContext());
        final View layoutView = inflator.inflate(R.layout.resupply_dialog_layout, null);

        builder.setView(layoutView);

        String[] options = new String[]{"Full", "Custom"};
        spinnerOptions = (Spinner) layoutView.findViewById(R.id.spinnerOptions);
        npSupply = (NumberPicker) layoutView.findViewById(R.id.npSupply);

        npSupply.setMaxValue(drug.getMaxSupply());
        npSupply.setMinValue(0);


        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, options);
        spinnerOptions.setAdapter(adapter);

        spinnerOptions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (adapterView.getSelectedItem().toString().equals("Full"))
                    npSupply.setVisibility(View.GONE);
                else
                    npSupply.setVisibility(View.VISIBLE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}
