package com.sep.medalert.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sep.medalert.R;
import com.sep.medalert.activities.UpdateOrAddDoctorActivity;
import com.sep.medalert.adapters.DoctorListAdapter;
import com.sep.medalert.model.Doctor;
import com.sep.medalert.util.DatabaseHelper;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Nelly on 16/09/2017.
 */

public class DoctorListFragment extends Fragment {

    private FloatingActionButton fab_addDoctor;
    private Animation FabOpen, FabRAnticlockwise;
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference firebaseReference;
    private ArrayList<Doctor> doctors;

    private RecyclerView rvDoctors;
    private RecyclerView.Adapter doctorsAdapter;
    private TextView tvHelpText;

    private DatabaseHelper databaseHelper;
    public DoctorListFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Initiate Database Handler
        databaseHelper = new DatabaseHelper(getActivity());
        databaseHelper.authoriseUser();

        getActivity().setTitle("Doctors");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_doctor_list, container, false);

        //////////////Initilisation of Dummy Data//////////////////
        doctors = new ArrayList<Doctor>();
        getData();

        tvHelpText = (TextView) view.findViewById(R.id.tvHelpText);

        // Adding custom adapter to listview to allow custom formatting of required fields in listview
        doctorsAdapter = new DoctorListAdapter(getActivity(), doctors);
        rvDoctors = (RecyclerView) view.findViewById(R.id.rvDoctors);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        rvDoctors.setHasFixedSize(true);

        // use a linear layout manager
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        rvDoctors.setLayoutManager(mLayoutManager);


        rvDoctors.setAdapter(doctorsAdapter);

        fab_addDoctor = (FloatingActionButton) view.findViewById(R.id.addDoctorBtn);
        FabOpen = AnimationUtils.loadAnimation(getActivity().getApplicationContext(), R.anim.addpres_open);
        FabRAnticlockwise = AnimationUtils.loadAnimation(getActivity().getApplicationContext(), R.anim.rotate_anticlockwise);

        fab_addDoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Turning Animation on Add Prescription Button
                fab_addDoctor.startAnimation(FabOpen);
                fab_addDoctor.startAnimation(FabRAnticlockwise);

                // go to addPrescriptionActivity
                Intent addNewIntent = new Intent(getActivity(), UpdateOrAddDoctorActivity.class);
                addNewIntent.putExtra("Type", "Add");
                startActivity(addNewIntent);
            }
        });

        return view;
    }

    public void getData() {
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseReference = firebaseDatabase.getReference();
        firebaseReference.child(user.getUid()).child("doctors").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // clears the list before adding new items to it so it doesn't get duplicates
                doctors.clear();

                for(DataSnapshot data: dataSnapshot.getChildren())  {
                    Doctor doctor = data.getValue(Doctor.class);
                    doctors.add(doctor);
                }

                sortDoctorsAlphabetically();
                // update the recyclerview when the data set is returned
                doctorsAdapter.notifyDataSetChanged();

                // show help text is list is empty
                if (doctors.size() > 0)
                    tvHelpText.setVisibility(View.GONE);
                else
                    tvHelpText.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    // pretty sure we can extract this into a utils class and just pass in doctors
    private void sortDoctorsAlphabetically() {
        Collections.sort(doctors, (p1, p2) -> p1.getName().toLowerCase().compareTo(p2.getName().toLowerCase()));
    }
}
