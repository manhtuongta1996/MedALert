package com.sep.medalert.util;

import android.app.Application;

import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by Tuong on 10/12/2017.
 */

public class myMedalert extends Application{
    @Override
    public void onCreate(){
        super.onCreate();
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);

    }
}
