package com.sep.medalert.notifications;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sep.medalert.R;
import com.sep.medalert.model.Drug;
import com.sep.medalert.model.PrescriptionInfo;

/**
 * Created by Jaspreet Panesar on 9/10/2017.
 */

public class AlarmReciever extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String drugId = intent.getStringExtra("drug-id");

        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference firebaseReference = firebaseDatabase.getReference();
        firebaseReference.child(user.getUid()).child("prescription").child(drugId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Drug drug = dataSnapshot.getValue(Drug.class);
                AlarmNotification.showNotification(context, intent, drug);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }});
    }







}
