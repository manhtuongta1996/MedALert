package com.sep.medalert.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.sep.medalert.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nelly on 12/10/2017.
 */

public class ImageListAdapter  extends RecyclerView.Adapter<ImageListAdapter.ViewHolder> {
    private LayoutInflater inflator;
    private Context context;
    private String imgString;
    private String selectedImage;
    private int numIdx;
    private List<ImageView> items;

    public ImageListAdapter(Context context, String imgString, int numIdx) {
        this.context = context;
        this.inflator = LayoutInflater.from(context);
        this.imgString = imgString;
        this.numIdx = numIdx;
        items = new ArrayList<>();
    }
    @Override
    public ImageListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.doctor_icon_list, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ImageListAdapter.ViewHolder holder, int position) {
        //Adds all ImageView items in array so they can be used in deleteBackgroundFromAll()
        items.add(holder.imgView);

        holder.imgView.setImageResource(context.getResources().getIdentifier("drawable/ic_"+ imgString + position, null, context.getPackageName()));

        //Sets background image for the image icon that is selected
        holder.imgView.setOnClickListener((View v) -> {
            deleteBackgroundFromAll();
            holder.imgView.setBackgroundResource(R.drawable.ic_highlightback);
            selectedImage = imgString + position;
        });


    }
    public String getSelectedImgView() {
        return selectedImage;
    }

    @Override
    public int getItemCount() {
        return numIdx;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgView;
        public ViewHolder(View itemView) {
            super(itemView);
            imgView = (ImageView) itemView.findViewById(R.id.imgView);
        }
    }
    private void deleteBackgroundFromAll() {
        for(ImageView item : items) {
            item.setBackgroundResource(0);
        }
    }
}
