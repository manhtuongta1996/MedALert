package com.sep.medalert.adapters;

/**
 * Created by Nelly on 16/09/2017.
 */

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Parcelable;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.sep.medalert.R;
import com.sep.medalert.activities.PrescriptionDetailsActivity;
import com.sep.medalert.model.Drug;

import java.util.ArrayList;
import java.util.Collections;

public class AllPrescriptionListAdapter extends RecyclerView.Adapter<AllPrescriptionListAdapter.ViewHolder> {
    private final String TAG = "CustomAdapter";
    private Context context;
    private ArrayList<Drug> prescriptions = new ArrayList<Drug>();

    public class ViewHolder extends RecyclerView.ViewHolder {
        protected TextView nameTv, descTv, supplyTv;
        protected ImageView presImgIv;
        protected CardView cardView;

        public ViewHolder(View view) {
            super(view);
            nameTv = (TextView) view.findViewById(R.id.tvPresName);
            descTv = (TextView) view.findViewById(R.id.tvPresDesc);
            supplyTv = (TextView) view.findViewById(R.id.tvPresSupply);
            presImgIv = (ImageView) view.findViewById(R.id.ivPresPill);
        }
    }

    public AllPrescriptionListAdapter(Context context, ArrayList<Drug> prescriptions) {
        this.context = context;
        this.prescriptions = prescriptions;
    }

    @Override
    public AllPrescriptionListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView =  LayoutInflater.from(parent.getContext())
                .inflate(R.layout.all_prescription_plan, parent, false);

        ViewHolder vh = new ViewHolder(itemView);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Drug drug = prescriptions.get(position);

        holder.nameTv.setText(drug.getName());
        holder.descTv.setText(drug.formatDesc());
        holder.supplyTv.setText("Supply: " + drug.buildRemainingSupplyString());
        holder.supplyTv.setTextColor(Color.parseColor(drug.getSupplyRemainingColour()));

        //Setting icon imageview. Need to first find the resource icon because setImageResource only takes in int
        holder.presImgIv.setImageResource(context.getResources().getIdentifier("drawable/ic_"+ drug.getUnit().toLowerCase(), null, context.getPackageName()));

        //Making each card clickable so can be taken into extra details page
        holder.itemView.setOnClickListener((View v) -> directToDetailsPage(v, drug));
    }

    private void directToDetailsPage(View v, Drug drug) {
        Intent detailsIntent = new Intent(v.getContext(), PrescriptionDetailsActivity.class);
        detailsIntent.putExtra("prescription", (Parcelable) drug);
        v.getContext().startActivity(detailsIntent);
    }


    @Override 
    public int getItemCount() {
        return prescriptions.size();
    }

}

