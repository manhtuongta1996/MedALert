package com.sep.medalert.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.sep.medalert.R;
import com.sep.medalert.model.Doctor;
import com.sep.medalert.util.DatabaseHelper;

public class DoctorDetailsActivity extends AppCompatActivity {

    private TextView tvName, tvMobile, tvPhone, tvFax, tvEmail, tvClinicName, tvClinicAddress, tvSpeciality;
    private Button btnEdit, btnDelete;
    private ImageView ivIcon;

    private DatabaseHelper databaseHelper;

    private Doctor doctor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_details);
        databaseHelper = new DatabaseHelper(this);
        databaseHelper.authoriseUser();


        doctor = getIntent().getParcelableExtra("doctor");
        setTitle(doctor.getName());
        // creates a back button on the action bar (getActionBar() did not work)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ////////////////////////////////////////

        initiliseViews();
        populateViews();

        btnDelete.setOnClickListener((View v) -> {deleteDoctor();});
        btnEdit.setOnClickListener((View v) -> {editDoctor();});
    }

    private void initiliseViews() {
        tvName = (TextView) findViewById(R.id.tvName);
        tvMobile   = (TextView) findViewById(R.id.tvMobile);
        tvPhone        = (TextView) findViewById(R.id.tvPhone);
        tvFax        = (TextView) findViewById(R.id.tvFax);
        tvEmail        = (TextView) findViewById(R.id.tvEmail);
        tvClinicName        = (TextView) findViewById(R.id.tvClinicName);
        tvClinicAddress        = (TextView) findViewById(R.id.tvClinicAddress);
        tvSpeciality        = (TextView) findViewById(R.id.tvSpeciality);
        ivIcon = (ImageView)findViewById(R.id.ivIcon);
        btnEdit = (Button) findViewById(R.id.btnEdit);
        btnDelete = (Button) findViewById(R.id.btnDelete);
    }

    private void populateViews() {
        tvName.setText(doctor.getName());
        tvMobile.setText(doctor.getMobile());
        tvPhone.setText(doctor.getPhone());
        tvFax.setText(doctor.getFax());
        tvEmail.setText(doctor.getEmail());
        tvClinicName.setText(doctor.getClinicName());
        tvClinicAddress.setText(doctor.getClinicAddress());
        tvSpeciality.setText(doctor.getSpeciality());

        if(!(doctor.getIcon() == null)) {
            ivIcon.setImageResource(getResources().getIdentifier("drawable/ic_"+ doctor.getIcon(), null, getPackageName()));
        } else {
            ivIcon.setImageResource(R.drawable.ic_unselected);
        }
    }

    private void deleteDoctor() {
        Runnable runnable = () -> { confirmDeleteDoctor(); };
        alertDialog(runnable, "Delete " + doctor.getName(), "Are you sure you want to delete this doctor?", "yes");
    }

    private void confirmDeleteDoctor() {
        Toast.makeText(getApplicationContext(), "Doctor Deleted", Toast.LENGTH_SHORT).show();
        deleteDoctorFromDb();
        finish();
    }

    //put in databaseHelper
    private void deleteDoctorFromDb() {
        databaseHelper.deleteDoctor(doctor.getPushId());
    }

    /**
     * *******Edit Prescription Methods *********
     */

    private void editDoctor() {
        // Toast.makeText(getApplicationContext(), "Edit Prescription" , Toast.LENGTH_SHORT).show();
        Intent editIntent = new Intent(this, UpdateOrAddDoctorActivity.class);
        editIntent.putExtra("doctor", doctor);
        editIntent.putExtra("Type", "Edit");
        startActivity(editIntent);
        finish(); //close
    }

    // clicking back button finishes activity
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // clicking back button
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

    /*
     *********Alert POP UP ***********
     */
    private void alertDialog(final Runnable runnable, String title, String message, String button) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(button,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) { new Handler().post(runnable);}
                });
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
