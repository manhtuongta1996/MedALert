package com.sep.medalert.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import java.util.ArrayList;

/**
 * Created by Nelly on 16/09/2017.
 */

public class Doctor implements Parcelable, Comparable<Doctor> {
    private String name, mobile,phone, fax, email, clinicName, clinicAddress, speciality, pushId, icon;

    public Doctor(){super();}

    public Doctor(String name, String mobile, String phone, String fax, String email, String clinicName, String clinicAddress, String speciality, String icon) {
        this.name = name;
        this.mobile = mobile;
        this.phone = phone;
        this.fax = fax;
        this.email = email;
        this.clinicName = clinicName;
        this.clinicAddress = clinicAddress;
        this.speciality = speciality;
        this.icon = icon;
    }

    public Doctor(Parcel parcel) {
        this.name = parcel.readString();
        this.mobile = parcel.readString();
        this.phone = parcel.readString();
        this.fax = parcel.readString();
        this.email = parcel.readString();
        this.clinicName = parcel.readString();
        this.clinicAddress = parcel.readString();
        this.speciality = parcel.readString();
        this.pushId = parcel.readString();
        this.icon = parcel.readString();
    }

    public static final Creator<Doctor> CREATOR = new Creator<Doctor>() {
        @Override
        public Doctor createFromParcel(Parcel in) {
            return new Doctor(in);
        }

        @Override
        public Doctor[] newArray(int size) {
            return new Doctor[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.name);
        parcel.writeString(this.mobile);
        parcel.writeString(this.phone);
        parcel.writeString(this.fax);
        parcel.writeString(this.email);
        parcel.writeString(this.clinicName);
        parcel.writeString(this.clinicAddress);
        parcel.writeString(this.speciality);
        parcel.writeString(this.pushId);
        parcel.writeString(this.icon);
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getClinicAddress() {
        return clinicAddress;
    }

    public void setClinicAddress(String clinicAddress) {
        this.clinicAddress = clinicAddress;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getPushId() { return pushId; }

    public void setPushId(String pushId) {this.pushId = pushId;}

    public String getIcon() { return icon; }

    public void setIcon(String icon) {this.icon = icon;}

    @Override
    public int compareTo(@NonNull Doctor anotherDoctor) {
        return anotherDoctor.getName().toLowerCase().compareTo(this.name.toLowerCase());
    }
}
