package com.sep.medalert.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sep.medalert.R;
import com.sep.medalert.util.DatabaseHelper;
import com.sep.medalert.adapters.TodayPrescriptionListAdapter;
import com.sep.medalert.model.Drug;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class TodayPrescriptionPlanFragment extends Fragment {
    private final String TAG = "PrescriptionPlan";
    private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference firebaseReference;
    private ArrayList<Drug> prescriptions;
    private RecyclerView.Adapter prescriptionsAdapter;
    private ArrayList<Drug> todayPrescriptions;
    private TextView tvHelpText, tvAlertsHelpText;

    private DatabaseHelper databaseHelper;

    public TodayPrescriptionPlanFragment() {

        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Initiate Database Handler
        databaseHelper = new DatabaseHelper(getActivity());
        databaseHelper.authoriseUser();

        prescriptions = new ArrayList<Drug>();
        todayPrescriptions = new ArrayList<Drug>();
        getData();
    }
    public void getData() {
        DatabaseReference databaseReference = databaseHelper.getFirabaseReference();
        databaseReference.child(databaseHelper.getUserId()).child("prescription").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // clears the list before adding new items to it so it doesn't get duplicates
                prescriptions.clear();

                for(DataSnapshot data: dataSnapshot.getChildren())  {
                    Drug drug = data.getValue(Drug.class);
                    prescriptions.add(drug);
                }

                getTodayData();
                //update the recyclerview when the data set is returned
                prescriptionsAdapter.notifyDataSetChanged();

                // show help text is list is empty
                if (prescriptions.size() > 0) {
                    tvHelpText.setVisibility(View.GONE);
                }
                else
                    tvHelpText.setVisibility(View.VISIBLE);

                // if there is something in prescription list, and nothing in today's list
                // - meaning there are no alerts today - then show alerts help text
                if (prescriptions.size() > 0 && todayPrescriptions.size() <= 0)
                    tvAlertsHelpText.setVisibility(View.VISIBLE);
                else
                    tvAlertsHelpText.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
    private void getTodayData(){
        todayPrescriptions.clear(); // clear the list before adding things to it
        String today = getTodayDate();

        for (Drug drug : prescriptions){
            if(!drug.getPrescriptionInfoAt(0).isTodayDate(today)) {
                databaseHelper.editPrescriptionInfoDay(drug, today);
            }
            if (drug.checkTodayPre() && drug.getPrescriptionInfoAt(0).isAvailableForToday()){
                todayPrescriptions.add(drug);
            }
        }

    }

    //I think this needs to go intoa  util class
    public String getTodayDate() {
        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();
        return new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date.getTime());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_prescription_list, container, false);

        //Adding custom adapter to listview to allow custom formatting of required fields in listview
        prescriptionsAdapter = new TodayPrescriptionListAdapter(getActivity(),todayPrescriptions);
        final RecyclerView prescriptionsRv = (RecyclerView) view.findViewById(R.id.rvPrescription);

        tvHelpText = (TextView) view.findViewById(R.id.tvHelpText);
        tvAlertsHelpText = (TextView) view.findViewById(R.id.tvAlertsHelpText);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        prescriptionsRv.setHasFixedSize(true);

        // use a linear layout manager
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        prescriptionsRv.setLayoutManager(mLayoutManager);


        prescriptionsRv.setAdapter(prescriptionsAdapter);


        return view;
    }

}
