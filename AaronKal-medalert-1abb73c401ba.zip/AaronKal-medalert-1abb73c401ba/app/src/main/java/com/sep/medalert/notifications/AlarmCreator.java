package com.sep.medalert.notifications;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.Build;
import android.support.v7.app.NotificationCompat;
import android.widget.Toast;

import com.sep.medalert.R;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Created by Jaspreet Panesar on 9/10/2017.
 */

public class AlarmCreator {

    // array used to convert PrescriptionInfo days to the respective Calendar Day
    public static int[] days = new int[] {Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
            Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY};

    public AlarmCreator() { super(); }

    /*
    * create a single alarm using a unique id
    * */
    public static void create(Context context, int id, String drug_id, int alertIndex, int hour, int minute, int day) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

            // create an intent for the alert
            Intent notificationIntent = new Intent(context, AlarmReciever.class);

            notificationIntent.putExtra("notification-id", id);
            notificationIntent.putExtra("drug-id", drug_id);
            notificationIntent.putExtra("alert-index", alertIndex);
            notificationIntent.putExtra("hour", hour);
            notificationIntent.putExtra("minute", minute);
            notificationIntent.putExtra("day", day);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, id, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

            // sets time for alarm
            Calendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(System.currentTimeMillis());
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            calendar.set(Calendar.DAY_OF_WEEK, days[day]);

            long time = calendar.getTimeInMillis();

            // if time has already passed, sets the alarm to go off 1 week later
            if (System.currentTimeMillis() > calendar.getTimeInMillis())
                time = calendar.getTimeInMillis() + AlarmManager.INTERVAL_DAY * 7;

            // schedule an alarm
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, time, pendingIntent);
            }
        } catch (Exception e) {return;}
    }

    /*
    * cancels a scheduled alarm based on the provided id
    * */
    public static void cancel(Context context, int id) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

            // recreate pending intent
            Intent notificationIntent = new Intent(context, AlarmReciever.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, id, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);


            // cancel alarm
            alarmManager.cancel(pendingIntent);
        } catch (Exception e) {return;}
    }


    public static void createSnooze(Context context, int id, String drug_id, int alertIndex, int hour, int minute, int day) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        // create an intent for the alert
        Intent notificationIntent = new Intent(context, AlarmReciever.class);

        notificationIntent.putExtra("notification-id", id);
        notificationIntent.putExtra("drug-id", drug_id);
        notificationIntent.putExtra("alert-index", alertIndex);
        notificationIntent.putExtra("hour", hour);
        notificationIntent.putExtra("minute", minute);
        notificationIntent.putExtra("day", day);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, id, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // schedule an alarm for 10 minutes from now
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 600000, pendingIntent);
        }
    }

}
