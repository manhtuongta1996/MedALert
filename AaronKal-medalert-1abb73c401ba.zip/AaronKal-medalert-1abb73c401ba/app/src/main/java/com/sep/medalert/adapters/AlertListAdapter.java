package com.sep.medalert.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sep.medalert.R;
import com.sep.medalert.model.PrescriptionInfo;

import java.util.ArrayList;

/**
 * Created by Jaspreet Panesar on 17/09/2017.
 */

public class AlertListAdapter extends RecyclerView.Adapter<AlertListAdapter.ViewHolder> {
    private LayoutInflater inflator;
    private Context context;
    private ArrayList<PrescriptionInfo> alertTimes = new ArrayList<PrescriptionInfo>();
    private String unit;

    ClickListener clickListener;

    public void setClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }

    public interface ClickListener {
        void ItemClicked(View v, int position);
    }


    public AlertListAdapter(Context context, ArrayList<PrescriptionInfo> alertTimes, String unit) {
        this.context = context;
        this.inflator = LayoutInflater.from(context);
        this.alertTimes = alertTimes;
        this.unit = unit;
    }

    @Override
    public AlertListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflator.inflate(R.layout.alert_time_list, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        PrescriptionInfo pinfo = alertTimes.get(position);
        holder.tvTime.setText(pinfo.timeFormatted());
        holder.tvDosage.setText(String.valueOf(pinfo.getDosage()) + " " + this.unit);
        holder.tvDaysList.setText(pinfo.daysList());

        // setting on click listeners for each item in the data
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (clickListener != null) {
                    clickListener.ItemClicked(view, position);
                }
            }
        });
    }



    @Override
    public int getItemCount() {
        return alertTimes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTime, tvDosage, tvDaysList;

        public ViewHolder(View itemView) {
            super(itemView);
            tvTime = (TextView) itemView.findViewById(R.id.tvTime);
            tvDosage = (TextView) itemView.findViewById(R.id.tvDosage);
            tvDaysList = (TextView) itemView.findViewById(R.id.tvDaysList);

        }
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

}
