package com.sep.medalert.notifications;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Jaspreet Panesar on 13/10/2017.
 */

public class SnoozeAlarmReciever extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        int id = intent.getIntExtra("notification-id", 0);
        String drugId = intent.getStringExtra("drug-id");
        int alertIndex = intent.getIntExtra("alert-index", 0);
        int hour = intent.getIntExtra("hour", 0);
        int minute = intent.getIntExtra("minute", 0);
        int day = intent.getIntExtra("day", 0);

        // close notification
        NotificationManager nManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nManager.cancel(id);

        // create alarm 10 minutes from now
        AlarmCreator.createSnooze(context, id, drugId, alertIndex, hour, minute, day);
    }
}
