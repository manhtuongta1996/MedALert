package com.sep.medalert.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.sep.medalert.R;
import com.sep.medalert.fragments.DoctorListFragment;
import com.sep.medalert.fragments.PrescriptionPlanFragment;
import com.sep.medalert.util.DatabaseHelper;


public class NavigationDrawerActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private final String TAG = "PrescriptionPlan";

    private DatabaseHelper databaseHelper;

    private CoordinatorLayout coordinatorLayout;
    private ActionBarDrawerToggle toggle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        coordinatorLayout = (CoordinatorLayout)findViewById(R.id.coordinatorLayout);

        databaseHelper = new DatabaseHelper(this);
        databaseHelper.authoriseUser();

        //sets PrescriptionPlan as default fragment to show on screen
        setFragment(new PrescriptionPlanFragment());

        ///////////////////Navigation Drawer////////////////////////////
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        //homeFragment();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Fragment fragment = null;
        switch(id) {
            case R.id.nav_pres_plan:
                fragment = new PrescriptionPlanFragment();
                break;
            case R.id.nav_add_pres:
                Intent addNewIntent = new Intent(this, UpdateOrAddPrescriptionActivity.class);
                addNewIntent.putExtra("Type", "Add");
                startActivity(addNewIntent);
                break;
            case R.id.nav_doctors:
                fragment = new DoctorListFragment();
                break;
            case R.id.nav_add_dr:
                Intent intent = new Intent(this, UpdateOrAddDoctorActivity.class);
                intent.putExtra("Type", "Add");
                startActivity(intent);
                break;
            case R.id.nav_about:
                startActivity(new Intent(this, AboutActivity.class));
                break;
            case R.id.nav_logout:
                databaseHelper.signout();
                startActivity(new Intent(NavigationDrawerActivity.this, LoginActivity.class));
                break;
            default:
                fragment = new PrescriptionPlanFragment();
        }

        if(fragment != null) {
            setFragment(fragment);
        }

        //Close Navigation Drawer
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        return true;
    }

    //Sets fragment in the view in content_main.xml
    public void setFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.content_main, fragment)
                .commit();
    }
}